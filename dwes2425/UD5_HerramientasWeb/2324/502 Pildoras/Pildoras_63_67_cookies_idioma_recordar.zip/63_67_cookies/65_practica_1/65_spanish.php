<!doctype html>
<html>

<head>
  <title>Video 65 Práctica 1 </title>
  <body style="background-color:rgb(246,243,229);">
</head>

  

<?php
/*
  Alumno: Nombre Apellido1 Apellido2
  Fecha: DD/MM/AAAA
  Finalidad: 
*/

?>

<h1> Página web del centro </h1>

<p> Bienvenidos a la página web del IES Francisco de los Ríos </p>
<img src="img/web_ies.png" width="250" height="187">

<a href="65_pag1.php">Volver</a>

</body>

</html>
