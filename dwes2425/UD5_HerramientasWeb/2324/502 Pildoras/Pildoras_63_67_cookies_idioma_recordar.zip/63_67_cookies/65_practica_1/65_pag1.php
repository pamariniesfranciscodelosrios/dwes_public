<!doctype html>
<html>

<head>
  <title>Video 65 Práctica 1 </title>
  <body style="background-color:rgb(246,243,229);">
</head>

  

<?php
/*
  Alumno: Nombre Apellido1 Apellido2
  Fecha: DD/MM/AAAA
  Finalidad: 
*/
/*

<table align="center">
  <tr>
    <td><h1>Elige idioma / choose language </h1> </td>
  </tr>
  <tr>
    <td align="center"><a href="65_creaCookie.php?idioma=es">Español
      <img src="img/spain.png" width="90" height="60">
  </td>
  
    <td align="center"><a href="65_creaCookie.php?idioma=en">Ingles<img src="img/uk.png" width="90" height="60">
  </td>
  </tr>
</table>
*/

setcookie("idioma_seleccionado","a");
?>



<a href="65_creaCookie.php?idioma=es">Español</a>
<a href="65_creaCookie.php?idioma=en">Ingles</a>





</body>

</html>
