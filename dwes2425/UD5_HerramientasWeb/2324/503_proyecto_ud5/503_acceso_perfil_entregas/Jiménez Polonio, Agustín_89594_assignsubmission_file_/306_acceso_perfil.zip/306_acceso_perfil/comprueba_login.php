<?php
    $username = $_POST['username'];
    $password = "admin";
    /*$date = $_POST['date'];
    $email = $_POST['email'];
    $tlf = $_POST['tlf'];
    $password = "admin";*/
    
    if (empty($username) || empty($password)) {
        $error = "<p style='color:red'>Debes introducir información en todos los campos!</p>";
        include "index.php";
        echo $error;       
    } else {
        if ($password == "admin") { 
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['date'] = "25-10-2022";
            $_SESSION['email'] = "agustin@gmail.com";
            $_SESSION['tlf'] = "456385394";
            setcookie("Gustos","Le gusta las gafas",time()+3600);
            setcookie("Altura","1.72",time()+3600);
            setcookie("Procedencia","España",time()+3600);
            include "perfil.php"; 
        } else {
            $error = "<p style='color:red'>Contraseña incorrecta!</p>";
            include "index.php";
            echo $error;
        }
    }
?>