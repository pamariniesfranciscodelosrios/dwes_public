<head>
<meta charset="utf-8">
<title>Perfil del usuario</title>
</head>
 
<body>
 
<?php
    //Que hacemos si no hay nada almacenado...
    if(!isset($_SESSION["username"])){
        header("Location:login.php");
    }
    echo "<h1>Mostrando datos de la sesión del usuario.</h1>";
    echo "<p>Bienvenido " .$_SESSION['username']." .</p>";
    echo "<p>Fecha de nacimiento: " .$_SESSION['tlf']." .</p>";
    echo "<p>Email: " .$_SESSION['email']." .</p>";
    echo "<p>Teléfono: " .$_SESSION['tlf']." .</p>";
    echo "<h1>Mostrando datos de las cookies del usuario.</h1>";
    echo $_COOKIE['Gustos']. "<br>";
    echo $_COOKIE['Altura']. "<br>";
    echo $_COOKIE['Procedencia']. "<br>";
?>
    <p>Pulse <a href="logout.php"> para cerrar sesión</a></p>
    <p>Pulse <a href="index.php"> para volver al inicio</a></p>
</body>