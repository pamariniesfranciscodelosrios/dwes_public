<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Info Cookies</title>
</head>
<body>
<?php
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
   
    die("Error - debe <a href='index.php'>identificarse</a>");
}
 
$usuario = $_SESSION['username'];
 
print "Hello ".$usuario;

echo "<h2>Lets's have a looj into superglobal $ _COOKIE</h2>";
//print_r($_COOKIE);
foreach($_COOKIE as $key => $valor){
    print "<br> KEY: ". $key. ", VALOR: " . $valor;
}
echo "<p>Press <a href='perfil.php'> back to profile</a></p>";
?>
</body>
</html>

