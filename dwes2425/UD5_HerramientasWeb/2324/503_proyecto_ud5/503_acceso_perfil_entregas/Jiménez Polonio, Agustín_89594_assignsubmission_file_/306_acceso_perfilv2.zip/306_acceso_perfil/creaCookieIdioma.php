<?php
    if(!isset($_SESSION)) {
        session_start();
    }

    if(!isset($_SESSION['username'])) {
        die("ERROR: debe indentificarse");
    }

    setcookie("idioma_seleccionado", $_GET["idioma"], time()+30000);
    $_GET["idioma"] == es ? header("Location:infoCookies.php") : header("Location:infoCookiesEnglish.php");
?>