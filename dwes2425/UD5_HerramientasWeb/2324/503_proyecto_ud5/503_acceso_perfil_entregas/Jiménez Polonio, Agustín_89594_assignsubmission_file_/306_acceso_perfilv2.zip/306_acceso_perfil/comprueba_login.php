<?php
    $username = $_POST['username'];
    $password = "admin";
    /*$date = $_POST['date'];
    $email = $_POST['email'];
    $tlf = $_POST['tlf'];
    $password = "admin";*/
    if (empty($username)) {
        $error = "<p style='color:red'>Debes introducir un usuario</p>";
        include "index.php";
        echo $error;       
    } else {
        if ($password == "admin") { 
            session_start();
            $_SESSION['username'] = $username;
            header("Location:perfil.php"); 
        } else {
            $error = "<p style='color:red'>Contraseña incorrecta!</p>";
            include "index.php";
            echo $error;
        }
    }
?>