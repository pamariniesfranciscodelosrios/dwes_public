<head>
<meta charset="utf-8">
<title>Perfil del usuario</title>
<style>
    body {
            background-color: #0b45b7;
            color: white;  
            background-image: url(https://wallpaperaccess.com/full/4456008.jpg);
            background-repeat : no-repeat;
            background-size  : cover;
    }
    h1 {
        color: black;
    }
</style>
</head>
 
<body>
 
<?php
   session_start();
    //Que hacemos si no hay nada almacenado...
    if(!isset($_SESSION["username"])){
        header("Location:login.php");
    }
  
    $_SESSION['date'] = "25-10-2022";
    $_SESSION['email'] = "agustin@gmail.com";
    $_SESSION['tlf'] = "456385394";
    setcookie("Gustos","Le gusta las gafas",time()+3600);
    setcookie("Altura","1.72",time()+3600);
    setcookie("Procedencia","España",time()+3600);

    echo "<h1>Mostrando datos de la sesión del usuario.</h1>";
    echo "<p>Bienvenido " .$_SESSION['username']." .</p>";
    echo "<p>Fecha de nacimiento: " .$_SESSION['tlf']." .</p>";
    echo "<p>Email: " .$_SESSION['email']." .</p>";
    echo "<p>Teléfono: " .$_SESSION['tlf']." .</p>";

    echo "<h1>Mostrando datos de las cookies del usuario.</h1>";
    echo $_COOKIE['Gustos']. "<br>";
    echo $_COOKIE['Altura']. "<br>";
    echo $_COOKIE['Procedencia']. "<br>";

    if(isset($_SESSION['visitas'])){
        $_SESSION['visitas']++;
    }   
     else{
       $_SESSION['visitas'] = 0;
    }

    echo "SESSION del usuario: ";
    print_r($_SESSION['visitas']);
?>
    <h1>Elige idioma para ver las cookies</h1>
    <table>
        <tr><td></td></tr>
        <tr>
            <!-- que hace ?idioma=es le pasa por $_GET variable idioma -->
            <td align="center"> <a href="creaCookieIdioma.php?idioma=es"> <img src="img/esp.png" width="90" height="60"></a></td>
            <td align="center"> <a href="creaCookieIdioma.php?idioma=en"> <img src="img/uk.jpg" width="90" height="60"></a></td>
            <td></td>
        </tr>
    </table>

    <p>Pulse <a href="logout.php"> para cerrar sesión</a></p>
    <p>Pulse <a href="index.php"> para volver al inicio</a></p>
    <p>Pulse <a href="olvido.php"> para eliminar las cookies</a></p>
    <br>
    <p>Pulse <a href="infoCookies.php"> para ver información acerca de las cookies</a></p>
    <p>Pulse <a href="infoSession.php"> para ver información acerca de las sesiones</a></p>
</body>