<?php
    if(!isset($_SESSION)) {
        session_start();
    }

    if(!isset($_SESSION['username'])) {
        die("ERROR: debe indentificarse");
    }

    if ($_GET["idioma"] == null || $_GET["idioma"] == "") {
        setcookie("idioma_seleccionado", "es");
        header("Location:infoCookies.php");
    } else {
        setcookie("idioma_seleccionado", $_GET["idioma"]);
        $_COOKIE["idioma_seleccionado"] == "es" ? header("Location:infoCookies.php") : header("Location:infoCookiesEnglish.php");
    }
?>