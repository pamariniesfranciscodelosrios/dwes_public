<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ryanair Registro</title>
    <style>
        body {
            background-color: #0b45b7;
            color: white;  
        }

        form {
            padding-top: 50px;
            width: 100%;
            height: 100vh;
            background-image: url(https://wallpaperaccess.com/full/4456008.jpg);
            background-repeat : no-repeat;
            background-size  : cover;
        }

        table {
            margin: 0 auto;
        }

        h1 {
            text-align: center;
        }
        
        p {
            text-align: center;
        }
    </style>
</head>
<body>  
    <svg viewBox="0 4 100 10" xmlns="http://www.w3.org/1000/svg" height="100%" width="100%"><path d="m23.8 14.3-2.8-3.7h-1.1v3.7h-3.3v-9.7h4.9c3.6 0 5.9 1 5.9 3 0 1.4-1.3 2.2-3.1 2.7l3.2 4zm-2.5-8h-1.5v2.7h1.6c1.7 0 2.6-.5 2.6-1.3.1-1-.7-1.4-2.7-1.4zm14.3 4.3v3.7h-3.3v-3.6l-4.8-6.1h3.6l1.4 2c.6.8 1.2 1.8 1.4 2.3.2-.5.8-1.5 1.4-2.3l1.4-2h3.6zm12.5 3.7-.9-2h-4.1l-.9 2h-3.4l4.7-9.7h3.2l4.7 9.7zm-2.1-4.8c-.3-.7-.7-1.9-.9-2.4-.1.5-.5 1.5-.8 2.3l-.5 1.2h2.7zm14.5 4.8-3.4-4.3c-.5-.6-1.1-1.4-1.4-2 0 .6.1 1.6.1 2.2v4.1h-3v-9.7h3.3l3.2 4.3c.4.6 1.1 1.5 1.5 2 0-.6-.1-1.7-.1-2.3v-4h3v9.7zm13.8 0-.9-2h-4.1l-.9 2h-3.4l4.7-9.7h3.3l4.7 9.7zm-2.1-4.8c-.3-.7-.7-1.9-.9-2.4-.1.5-.5 1.5-.8 2.3l-.5 1.2h2.7zm6.8 4.8v-9.7h3.3v9.7zm13.4 0-2.9-3.7h-1.1v3.7h-3.3v-9.7h4.9c3.6 0 5.9 1 5.9 3 0 1.4-1.3 2.2-3.1 2.7l3.2 4zm-2.5-8h-1.5v2.7h1.6c1.7 0 2.6-.5 2.6-1.3.1-1-.7-1.4-2.7-1.4z" fill="#fff"></path><g fill="#f1c931"><path d="m11.2 4.2c.7.2 1.4.4 2.1.5h.5c.3 0 .5-.1.8-.2h.1c0 .1 0 .1-.1.2-.4.3-.8.5-1.2.6-.1 0-.3.1-.4.1-.5.2-1.1.2-1.6.2-1-.1-1.9-.4-2.9-.4-.9-.1-1.8.3-2.3 1-.1.4-.3.8-.3 1.2s.6.5.8.8l.3.6c.1.4.3.8.6 1.2.2.2.4.5.7.6.4.3.7.6.9 1s.4.7.5 1.1c.1.2.2.4.2.7v.1c.1.2.1.4.2.5v.1c0 .1.1.3 0 .3-.2-.2-.3-.4-.4-.6-.1-.4-.4-.8-.7-1.2-.2-.2-.4-.5-.6-.7-.8-.9-2-1.5-2.9-2.3 0 0 0-.1-.1-.2-.1-.2-.2-.3-.3-.5-.2-.4-.5-.8-.7-1.3 0-.2-.1-.4-.1-.6v-.1c0-.2-.5-.3-.2-.7.2-.2.8-.4 1-.8v-.2s0-.1-.1-.1-.4.2-.4-.1v-.3c.1-.2.1-.4.1-.6 0-.1.1-.1.2-.1s.3-.1.4-.1c.3 0 .7 0 .9.2.1.2 0 .4 0 .6s-.2.3-.1.4h.2c.4-.3.8-.7 1.2-1.1.3-.3.8-.4 1.2-.3.9 0 1.6.3 2.5.5z"></path><path d="m8.9 5.8c.1.2 0 .3-.1.5-.5.7-.7 1.6-1 2.4h-.1c-.1 0-.1-.1-.1-.2 0-.9.3-1.7.7-2.5.1-.1.2-.3.4-.2.1-.1.1 0 .2 0zm1.4.2c.1.3-.1.5-.2.8-.5 1-1.1 2-1.4 3.1 0 0 0 .1-.1.1h-.1c-.1-.4 0-.9.1-1.3.3-.9.6-1.8 1.1-2.7.1 0 .1-.1.1-.1.2 0 .4 0 .5.1zm1.4.1c.1.1.1.3 0 .4-.6 1.3-1.5 2.4-1.9 3.8l-.3.9c0 .1-.1.1-.1 0-.1-.1 0-.3 0-.4.1-1.1.4-2.2.9-3.1.2-.5.5-.9.7-1.4.1-.1.2-.3.4-.3.1 0 .2 0 .3.1zm1.6.1c.1.2 0 .3 0 .5-.4 1-1.1 1.9-1.6 2.9-.5.8-.8 1.7-1.1 2.5-.1.3-.2.5-.3.8h-.1c-.1-.1-.1-.2-.1-.3.1-1.1.5-2 .9-3 .5-1.1 1.1-2.1 1.6-3.2.1-.1.2-.3.4-.4.1 0 .2 0 .3.2z"></path></g></svg>
    <form action="login.php" method="post">
        
        <h1>Registro en Ryanair</h1>

        <table>
            <tr>
                <td class="izq"> Usuario </td>
                <td class="der"><input type="text" name="username" id="username"> </td>
            </tr>
            <tr>
                <td class="izq"> Contraseña</td>
                <td class="der"><input type="password" name="password" id="password"> </td>
            </tr>
            <tr>
                <td class="izq"> Fecha de nacimiento</td>
                <td class="der"><input type="date" name="date" id="date"> </td>
            </tr>
            <tr>
                <td class="izq"> Email</td>
                <td class="der"><input type="email" name="email" id="email"> </td>
            </tr>
            <tr>
                <td class="izq"> Teléfono</td>
                <td class="der"><input type="number" name="tlf" id="tlf"> </td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="enviar" value="Enviar"> </td>
            </tr>      
        </table>
        <p>Pulse <a href="index.php"> para volver al inicio</a></p>
    </form>
</body>
</html>