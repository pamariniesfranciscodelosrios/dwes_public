<?php
//Recuperamos la sesion
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
    
    die("Error - debe <a href='index.php'>identificarse</a>");
}
//Creamos la cookie cuya clave es idioma_seleccionado y valor idioma,
//el cual es pasado como parametro por la url de nuestro navegador.
setcookie("idioma_seleccionado", $_GET["idioma"],time()+30000);
//Si el idioma es español se refirige a la página española
if($_GET['idioma'] == "es"){
header("location:infocookies.php");
//Si no a la inglesa
}else{
    header("location:infocookieng.php");
}
?>