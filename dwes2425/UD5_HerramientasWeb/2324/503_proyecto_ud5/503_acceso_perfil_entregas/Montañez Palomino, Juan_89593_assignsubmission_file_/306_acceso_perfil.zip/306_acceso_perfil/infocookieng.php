<?php
//Recuperamos la sesion
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
   
    die("Error - debe <a href='index.php'>identificarse</a>");
}
 
$usuario = $_SESSION['username'];
 
print "Hello ".$usuario."<br>";
print "<center><img src='./img/cookie.jpg' width='150' height='100'/> </center>";
print "<p>Cookies, are stored on our Computer. They can store, for example, the date, time and time spent on the Web </p>";
print "<p> Different purposes, info needed to browse the web. Online stores, info of everything leading to the Shopping Cart...</p>";
print "<p> Great potential for advertising by saving browsing habits</p>";
print "<p>For not too long there has been a law that the user must be warned and asked if information is stored in Cookies.</p>";
print "<p>It can remain in the hard disk what the programmer wants.</p>"; print "<p>Menu browser.... Delete cookies.</p>";
print "<p>Comes from the Hansel and Gretel fairy tale analogy of find your way back with breadcrumbs. </p>";
print "<p>If we do not specify the lifetime in the cookie, it is 0 (it is deleted when the computer is closed) by default </p>";
print "<p>If we do not specify the DIRECTORY where the cookie works, it works on the current and subdirectories (4 parameter)</p>";

 
echo "<h2>We show the superglobal cookie variable $ _COOKIE</h2>";
//print_r($_COOKIE);
foreach($_COOKIE as $key => $valor)
    print "<br> KEY: ". $key. "      VALOR: " . $valor;
?>
<p><a href="perfil.php">Click</a> to return to profile</p>
