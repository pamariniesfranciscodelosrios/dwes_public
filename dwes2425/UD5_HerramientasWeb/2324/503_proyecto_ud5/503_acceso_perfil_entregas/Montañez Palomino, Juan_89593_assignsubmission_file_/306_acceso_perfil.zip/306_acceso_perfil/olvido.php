<?php
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
   
    die("Error - debe <a href='index.php'>identificarse</a>");
}
 
 
$usuario = $_SESSION['username'];
 
print "Hola ".$usuario."<br>";

print "Procedemos a borrar los datos de la cookie:<br>";
//Derecho de Olvido: Borramos cookies


echo "<h2>Hemos borrado las COOKIES (expire negativo) $ _COOKIE</h2>";
//Recorremos con un blucle la variable $_COOKIE y sobreescribinedo la clave/valor con un tiempo en negativo
foreach($_COOKIE as $key => $valor){
    print "<br> Borrando ... KEY: ". $key. ", VALOR: " . $valor;
    setcookie($key, $valor, time()-100);
}
?>


<p><a href="https://www.php.net/manual/es/features.sessions.php" target="_blank">Manual PHP Cookies</a> Más info acerca de Cookies en este manual</p>


<p><a href="infocookies.php">Pulse</a> para ver las Cookies almacenadas</p>
<p><a href="infosession.php">Pulse</a> para ver las Sesiones almacenadas</p>
<p><a href="registro.php">Pulse</a> para ir a registro</p>
<p><a href="logout.php">Pulse</a> para cerrar session</p>
<p><a href="perfil.php">Pulse</a> para volver al perfil</p>