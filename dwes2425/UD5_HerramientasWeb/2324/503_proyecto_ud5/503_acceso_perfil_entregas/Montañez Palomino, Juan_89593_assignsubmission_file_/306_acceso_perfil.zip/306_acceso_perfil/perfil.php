<?php
//Recuperamos la sesion
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
    
    die("Error - debe <a href='index.php'>identificarse</a>");
}
$usuario = $_SESSION['username'];

print "Hola ".$usuario."<br>";

// Comprobamos si la variable visitas ya existe dentro de la sesion
if (isset($_SESSION['visitas']))
//Si es asi sumamos +1
$_SESSION['visitas']++;
else
//Sino la creamos e iniciamos a 0
$_SESSION['visitas'] = 0;


echo "SESSION: " ;
print_r($_SESSION['visitas']);

?>
<tr>
    <td><h1>Elige un idioma</h1></td>
</tr>
<tr>
    <td align:center><a href="infocookies.php"> <img src="img/idiom.jpg" width="90" height="60"></a></td>
    <td align:center><a href="creaCookieidioma.php?idioma=es"> <img src="img/esp.png" width="90" height="60"></a></td>
    <td align:center><a href="creaCookieidioma.php?idioma=en"> <img src="img/uk.jpg" width="90" height="60"></a></td>
</tr>
<p><a href="registro.php">Pulse</a> para registrarse</p>
<p><a href="logout.php">Pulse</a> para cerrar session</p>
<p><a href="olvido.php">Pulse</a> para borrar las cookies alamacenadas</p>
<p><a href="infocookies.php">Pulse</a> para ver las cookies almacenadas</p>
<p><a href="infosession.php">Pulse</a> para la informacion de la sessión</p>
