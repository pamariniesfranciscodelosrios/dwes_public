<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body class="body">
<form class="formulario">
    <h1 class="h1">Register</h1>
    <div class="inputs">
        <input placeholder="Username">
        <input type="email" placeholder="Email">
        <input type="password" placeholder="Password">
        <input type="edad" placeholder="Cual es tu edad">
        <input type="profesion" placeholder="Cual es tu trabajo">
    </div>

    <button class="btn"><a href="index.php">Registrar</a></button>
</form>
</body>
</html>

<?php




?>
