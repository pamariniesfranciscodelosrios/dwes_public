<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title> CSS Login Screen Tutorial </title>
</head>
<body>
<body>
<div class="login-page">
    <div class="form">
        <div class="login">
            <div class="login-header">
                <h3>AMAZON</h3>
                <p>Please enter your credentials to login.</p>
            </div>
        </div>
        <form class="login-form"  action="login.php" method="post">
            <input type="text" name="username" placeholder="username"/>
            <input type="password" name="password" placeholder="password"/>
            <button type="submit" name="enviar" value="Login">login</button>
            <p class="message">No esta registrado? <a href="register.php">Create an account</a></p>
        </form>
    </div>
</div>
</body>
</body>
</html


