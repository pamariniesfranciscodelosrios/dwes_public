<?php
    if(isset($_POST['enviar'])){
        $usuario=$_POST['username'];
        $password=$_POST['password'];

        if(empty($usuario) || empty($password)){
            $error="Deber introducir una contraseña y correo";
            print ("<h1 style='color: red'>$error</h1>");
            include "index.php";
        }else{
            if($usuario =="admin" && $password=="admin"){
                session_start();
                $_SESSION['username'] = $usuario;
                $_SESSION['password'] = "************";
                $_SESSION['edad'] = 20;
                $_SESSION['email'] = "byfunky79@gmail.com";
                $_SESSION['profesion'] = "Arbañil";
                header("location: main.php");;
            }else{
                $error= "Usuario o contraseña no validos";
                print ("<h1 style='color: red'>$error</h1>");
                include "index.php";
            }
        }
    }

?>
