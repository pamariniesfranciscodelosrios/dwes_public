<?php
session_start();
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
   
    die("Error - debe <a href='index.php'>identificarse</a>");
}




$usuario = $_SESSION['username'];
 
print "<h2>Hello ".$usuario. "</h2>";

 
echo "<h2>All cookies $ _COOKIE</h2>";
//print_r($_COOKIE);
foreach($_COOKIE as $key => $valor)
    print "<br> KEY: ". $key. ", VALOR: " . $valor;

echo "<br><br><a href='main.php'> Volver al perfil</a>"
?>


<p><a href="https://www.php.net/manual/es/features.sessions.php" target="_blank">Manual PHP Cookies</a> for more info in this manual</p>
<p><a href="infoSession.php">Click</a>  to show all sessions</p>
<p><a href="main.php">Click</a>  to go perfil</p>
<p><a href="register.php">Click</a> to register</p>
<p><a href="logout.php">Click</a> to logout</p>
