<html>
    <body>
<?php
if (!isset($_SESSION)) {
    session_start();
}
//Comprobamos que el usuario se haya autentificado
if(!isset($_SESSION['username'])){
   
    die("Error - debe <a href='index.php'>identificarse</a>");
}

$usuario = $_SESSION['username'];
 
print "<h2>Hola ".$usuario. "</h2>";
 

echo "<h2>Mostramos la variable superglobal de las sesiones $ _SESSION</h2>";
//print_r($_COOKIE);
foreach($_SESSION as $key => $valor)
    print "<br> KEY: ". $key. ", VALOR: " . $valor;

echo "<br><br><a href='main.php'> Volver al perfil</a>"
?>

<p><a href="https://www.php.net/manual/es/features.sessions.php" target="_blank">Manual PHP Cookies</a> Más info acerca de Cookies en este manual</p>
<p><a href="privado/infoCookiesPrivado.php">Pulse</a> para ver las COOKIES PRIVADAS</p>
<p><a href="infoCoockies.php.php">Pulse</a> para ver las COOKIES</p>
<p><a href="main.php">Pulse</a> para ir a perfil</p>
<p><a href="register.php">Pulse</a> para ir a registro</p>
<p><a href="logout.php">Pulse</a> para cerrar session</p>

    </body>


</html>

