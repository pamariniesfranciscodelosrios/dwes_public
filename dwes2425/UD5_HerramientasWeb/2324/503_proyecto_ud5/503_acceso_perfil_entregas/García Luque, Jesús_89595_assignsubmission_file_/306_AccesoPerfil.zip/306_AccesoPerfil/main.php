<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body class="">
<?php
session_start();
?>
<button class="button"><a  href="olvido.php">Olvido</a></button>
<br><br>

<button class="button"><a  href="logout.php">Cerrar Sesion</a></button>



<?php


print "<br><br><br><br><br><br><br><br>";
print  "<h1 style='color: white; text-align: center'>Bienvenido " . $_SESSION['username']. "</h1>";
print  "<h1 style='color: white; text-align: center'>Contraseña: " . $_SESSION['password']. "</h1>";
print  "<h1 style='color: white; text-align: center'>Email: " . $_SESSION['email']. "</h1>";
print  "<h1 style='color: white; text-align: center'>Edad: " . $_SESSION['edad']. "</h1>";
print  "<h1 style='color: white; text-align: center'>Profesion: " . $_SESSION['profesion']. "</h1>";

setcookie("hola","Esta es una cookie de bienvenida");
setcookie("Almacenamiento","Esta es una cookie de almacenamiento");
setcookie("Galeria","Esta es una cookie de galeria")

?>

<div class="ass"><a style="text-align: center" href="infoCoockies.php">PULSA AQUI PARA VER LAS COOKIES 🍪</a> <br> <br>
    <a href="infoSession.php">PULSA AQUI PARA VER LAS SESIONES</a><br> <br>
    <a href="register.php">PULSA AQUI PARA IR AL REGISTRO</a>
<br> <br>

</div>

<div class="imagenes">
    <a href="infoCoockies.php"><img style="width: 220px;" src="./img/idiom.jpg" alt=""></a>
    <a href="creaCookieIdioma.php?idioma=es"><img style="width: 220px;" src="./img/esp.png" alt=""></a>
    <a href="creaCookieIdioma.php?idioma=en"><img style="width: 220px;"  src="./img/uk.jpg" alt=""></a>
</div>

</body>
</html>

