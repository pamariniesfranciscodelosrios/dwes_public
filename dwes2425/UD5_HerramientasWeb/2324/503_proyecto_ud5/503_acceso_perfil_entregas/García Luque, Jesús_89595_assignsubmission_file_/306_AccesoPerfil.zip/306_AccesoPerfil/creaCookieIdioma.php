<?php

if (isset($_SESSION)){
    session_start();
}

if(($_SESSION['username'])){
    die("Error - debe <a href='index.php'>Identificarse</a>");

}

setcookie("idioma_seleccionado",$_GET["idioma"], time()+30000);
header("location:infoCoockies.php");

?>