<!doctype html>
<html lang="en">
<head>
    <link href="perfil.css"
          rel="stylesheet" type="text/css">

    <title>Perfil</title>
</head>
<body>


<aside class="profile-card">
    <header>
        <a target="_blank" href="#">
            <img src="https://img.freepik.com/vector-gratis/hombre-muestra-gesto-gran-idea_10045-637.jpg?w=740&t=st=1666698679~exp=1666699279~hmac=0e276848babeaecccdfbac575eaebf4929b375e49f8a166bdc5b1deefab52db2"
                 class="hoverZoomLink">
        </a>

        <h1>
            Eduardo
        </h1>

        <h2>
            Carmona
        </h2>

    </header>

    <div class="profile-bio">

        <p>
            It takes monumental improvement for us to change how we live our lives. Design is the way we access that
            improvement.
        </p>

    </div>
</aside>
</body>
</html>