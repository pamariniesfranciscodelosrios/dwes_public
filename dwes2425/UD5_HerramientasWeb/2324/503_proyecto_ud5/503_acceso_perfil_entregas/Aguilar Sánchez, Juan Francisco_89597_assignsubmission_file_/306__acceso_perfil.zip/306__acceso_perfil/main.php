<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix-Perfil</title>
    <style>
        body {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            max-width: 100%;
            background-image: url(https://bit.ly/2E3scwW);
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            background-color: #b3b3b3;
            background-blend-mode: multiply;
        }
        /* From uiverse.io by @alexmaracinaru */
        .card {
            width: fit-content;
            height: fit-content;
            padding: 0px 4em 1em 4em;
            background: rgba(0, 0, 0, 0.90);
            border-radius: 15px;
            box-shadow: 1px 5px 60px 0px #100a886b;
        }

        .card .card-border-top {
            width: 100%;
            height: 15px;
            background: rgba(255, 255, 255, 0.45);
            margin: auto;
            margin-top: 0px;
            border-radius: 0px 0px 15px 15px;
        }

        .card span {
            font-weight: 600;
            color: white;
            text-align: center;
            display: block;
            padding-top: 10px;
            font-size: 25px;
        }

        .card .job {
            font-weight: 400;
            color: white;
            display: block;
            text-align: center;
            padding-top: 3px;
            font-size: 15px;
        }

        .card .img {
            width: 70px;
            height: 70px;
            background: rgba(255, 255, 255, 0.50);
            border-radius: 15px;
            margin: auto;
            margin-top: 25px;
            padding: 5px;
        }

        .card button {
            padding: 8px 25px;
            display: block;
            margin: auto;
            border-radius: 2px;
            border: none;
            margin-top: 30px;
            background: #ff0000;
            color: white;
            font-weight: 300;
        }
        .a-btn{
            color: white;
            text-decoration: none;
        }

        .card button:hover {
            background: #fa2222;
        }
    </style>
</head>

<body>
<?php
/*
 Alumno: Juan F Aguilar Sanchez
 Fecha: 19/10/2022
 Finalidad: Ejercicios Tema 3 Conexion BBDD
 */
?>
<div class="card">
    <div class="card-border-top" ></div>
    <div class="img" ><img height="100%" width="100%" src="https://cdn-icons-png.flaticon.com/512/456/456283.png"></div>
    <?php
    //Que se hace en caso de no encontrar nada almacenado. Nos redirige de vuelta al login.
    if (!isset($_SESSION["username"])){
        header("Location: index.php");
    }
    print "<span>".$_SESSION["username"]."</span>";
    print "<p class='job'>Password: ".$_SESSION["password"]."</p>";
    print "<p class='job'>Age: ".$_SESSION["age"]."</p>";
    ?>

    <button><a class="a-btn" href="logout.php">Logout</a></button>
</div>
</body>

</html>